#lopullinen versio


#requirements.txt sisältää:
#google-cloud-secret-manager
#psycopg2


#tämä funktio vähentää ostoskorin tuoteriviltä yhden kappaleen

#ottaa vastaan gatewayn get-pyynnössä customer-id:n ja product_id:n
#tarkistaa onko tuotetta korissa vähintään 1 kpl
#vähentää yhden kappaleen korista
#lisää yhden varastoon
#rollback jos molemmat ei tapahtunu

from google.cloud import secretmanager
from configparser import ConfigParser
import psycopg2
from datetime import datetime
import requests
 
def remove_one_from_cart(request): #requestissa customer_id ja product_id
    print("request on", request)
    #jasonista sisällöt muuttujiin:
    jasoni =request.get_json()
    asiakas = jasoni['customer_id']
    print("asiakas on", asiakas)
    tuote = jasoni['product_id']
    print("tuote on", tuote)
    
    #secretmanagerista muuttujat ip, sqluser ja salasana(pw):
    client = secretmanager.SecretManagerServiceClient()
    ip2 = client.access_secret_version(request={"name": "projects/29618385328/secrets/sql-ipv42/versions/latest"})
    ip = ip2.payload.data.decode("UTF-8")
    pw2 = client.access_secret_version(request={"name": "projects/29618385328/secrets/sql-password2/versions/latest"})
    pw = pw2.payload.data.decode("UTF-8")
    sqluser2 = client.access_secret_version(request={"name": "projects/29618385328/secrets/sql-user2/versions/latest"})
    sqluser = sqluser2.payload.data.decode("UTF-8")


    #tarkasta onko korissa tuotetta min 1 kpl, palauta myös varastosaldo:
    amount_ok = amount_in_cart(tuote)
    testilista = [asiakas, tuote] #poistetaan korista yksi kpl tätä tuotetta
    testilista2 = [tuote] #päivitetään varastosaldo nykyinen saldo + 1 lukemaksi

    if amount_ok == True:
        print("tuli iffiin")
        #alkutestiin lisäystä varastoon ostettavaksi:
        #SQL_4 = '''INSERT INTO storage (product_id, amount) 
        #VALUES (%s, %s);'''
        #data_4 = (tuote, 20)
        SQL_1 = '''UPDATE shoppingcart SET amount = amount -1 WHERE customer_id = %s AND product_id = %s;'''
        #vähentää storagesta shopping cartiin lisätyn määrän
        SQL_2 = '''UPDATE storage SET amount = amount + 1 WHERE product_id = %s 
        ;'''
        #shopping cartiin lisätään:
        data_1 = (testilista)
        #storagesta vähennetään:
        data_2 = (testilista2)

        conn = None
        #updated_rows = 0
        try:
            print("tuli ekan tryhin")
            # connect to the PostgreSQL database
            conn = psycopg2.connect(host=ip, database="piirakka", port = 5432, user=sqluser, password=pw)
            # create a new cursor
            cur = conn.cursor()
            # execute the UPDATE  statement
            #cur.execute(SQL_4, data_4)
            cur.execute(SQL_1, data_1)
            cur.execute(SQL_2, data_2)

            # Commit the changes to the database
            conn.commit()
            # Close communication with the PostgreSQL database
            cur.close()
        except (Exception, psycopg2.DatabaseError) as error:
            conn.rollback()
            print(error)
            print("operation was cancelled. No changes were made to the amount in storage or to the shopping cart.")
        finally:
            print("finaaliin tuli!")
            if conn is not None:
                conn.close()
    else:
        print(f"not enought products in storage. Maximum amount to purchase at the moment is {num}")


def amount_in_cart(tuote: str):
    #tarkasta onko varastossa tuotetta min 1:
    #tee sql kysely,true jos tuotetta cartissa >= 1 kpl
    SQL_3 = '''SELECT amount FROM shoppingcart WHERE product_id = %s;'''
    data_3 = (tuote)

    #secretmanagerista muuttujat ip, sqluser ja salasana(pw):
    client = secretmanager.SecretManagerServiceClient()
    ip2 = client.access_secret_version(request={"name": "projects/29618385328/secrets/sql-ipv42/versions/latest"})
    ip = ip2.payload.data.decode("UTF-8")
    pw2 = client.access_secret_version(request={"name": "projects/29618385328/secrets/sql-password2/versions/latest"})
    pw = pw2.payload.data.decode("UTF-8")
    sqluser2 = client.access_secret_version(request={"name": "projects/29618385328/secrets/sql-user2/versions/latest"})
    sqluser = sqluser2.payload.data.decode("UTF-8")


    #num = 0 #poista tämä, kun homma toimii
    #amount_ok = False #poista tämä, kun homma toimii
    conn = None
    try:
        print("tuli tokan tryhin")
        # connect to the PostgreSQL database
        conn = psycopg2.connect(host=ip, database="piirakka", port = 5432, user=sqluser, password=pw)
        # create a new cursor
        cur = conn.cursor()
        # execute the UPDATE  statement
        cur.execute(SQL_3, data_3)
        lista = cur.fetchall()
        num = lista[0][0]
        print("num täällä on", num)
        if num >= 1:
            amount_ok = True
        else:
            amount_ok = False
            print("tuli tänne tokan funktion elseen")
        # Close communication with the PostgreSQL database
        cur.close()
    except:
        print("pieleen meni!")
    finally:
        if conn is not None:
            conn.close()

    #amount_ok = True #tämätestivaiheessa tarvittaessa
    #num = 9 #montako on varastossa tarvittaessa
    return amount_ok
