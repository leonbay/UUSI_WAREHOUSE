from google.cloud import secretmanager
import requests
import psycopg2

def poistoa(self):
    client = secretmanager.SecretManagerServiceClient()
    ip2 = client.access_secret_version(request={"name": "projects/29618385328/secrets/sql-ipv42/versions/1"})
    ip = ip2.payload.data.decode("UTF-8")

    pw2 = client.access_secret_version(request={"name": "projects/29618385328/secrets/sql-password2/versions/1"})
    pw = pw2.payload.data.decode("UTF-8")

    sqluser2 = client.access_secret_version(request={"name": "projects/29618385328/secrets/sql-user2/versions/1"})
    sqluser = sqluser2.payload.data.decode("UTF-8")
    con = psycopg2.connect(host=(ip), database = "piirakka", port=5432, user=(sqluser),password=(pw))
    cursor = con.cursor()
    SQL = "DELETE FROM shoppingcart WHERE updated_at < (NOW() - INTERVAL '60 MINUTE');"
    cursor.execute(SQL)
    con.commit()
    con.close()
    return 'success'