from google.cloud import secretmanager
import psycopg2
import requests

""" from google.cloud import secretmanager
import psycopg2
import requests

def populate_tables(just):

    client = secretmanager.SecretManagerServiceClient()
    ip2 = client.access_secret_version(request={"name": "projects/29618385328/secrets/sql-ipv42/versions/latest"})
    ip = ip2.payload.data.decode("UTF-8")

    pw2 = client.access_secret_version(request={"name": "projects/29618385328/secrets/sql-password2/versions/latest"})
    pw = pw2.payload.data.decode("UTF-8")

    sqluser2 = client.access_secret_version(request={"name": "projects/29618385328/secrets/sql-user2/versions/latest"})
    sqluser = sqluser2.payload.data.decode("UTF-8")

    sql = (
        """INSERT INTO customer (username, adress, email) VALUES ('matti', 'kotikatu 1b', 'matti@gmail.com');""",
        """INSERT INTO customer (username, adress, email) VALUES ('jussi', 'kotikatu 2b', 'jussi@gmail.com');""",
        """INSERT INTO customer (username, adress, email) VALUES ('keijo', 'kotikatu 3b', 'keijo@gmail.com');""",
        """INSERT INTO product (pname, category, prize, info) VALUES ('peruspiirakka', 'ilmantaytetta', 2.50, 'tama on hyvaa');""",
        """INSERT INTO product (pname, category, prize, info) VALUES ('munavoipiirakka', 'taytteella', 3.50, 'tama on tosi hyvaa');""",
        """INSERT INTO product (pname, category, prize, info) VALUES ('lohipiirakka', 'taytteella', 4.50, 'tama on erittain hyvaa');""",
        """INSERT INTO storage (amount, product_id) VALUES (60, 1);""",
        """INSERT INTO storage (amount, product_id) VALUES (30, 2);""",
        """INSERT INTO storage (amount, product_id) VALUES (10, 3);""",
    )

    try:
        con = psycopg2.connect(host=(ip), database = "piirakka", port=5432, user=(sqluser),password=(pw))

        cur = con.cursor()
        
        for command in sql:
            cur.execute(command)
        # close communication with the PostgreSQL database server
        cur.close()
        # commit the changes
        con.commit()
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
            con.close()
 """

def populate_tables(just):

    client = secretmanager.SecretManagerServiceClient()
    ip2 = client.access_secret_version(request={"name": "projects/29618385328/secrets/sql-ipv42/versions/1"})
    ip = ip2.payload.data.decode("UTF-8")

    pw2 = client.access_secret_version(request={"name": "projects/29618385328/secrets/sql-password2/versions/1"})
    pw = pw2.payload.data.decode("UTF-8")

    sqluser2 = client.access_secret_version(request={"name": "projects/29618385328/secrets/sql-user2/versions/1"})
    sqluser = sqluser2.payload.data.decode("UTF-8")

    sql = (
        """INSERT INTO customer (username, adress, email) VALUES ('matti', 'kotikatu 1b', 'matti@gmail.com')""",
        """INSERT INTO customer (username, adress, email) VALUES ('jussi', 'kotikatu 2b', 'jussi@gmail.com')""",
        """INSERT INTO customer (username, adress, email) VALUES ('keijo', 'kotikatu 3b', 'keijo@gmail.com')""",
        """INSERT INTO product (pname, category, prize, info) VALUES ('peruspiirakka', 'ilmantaytetta', 2.50, 'tama on hyvaa')""",
        """INSERT INTO product (pname, category, prize, info) VALUES ('munavoipiirakka', 'taytteella', 3.50, 'tama on tosi hyvaa')""",
        """INSERT INTO product (pname, category, prize, info) VALUES ('lohipiirakka', 'taytteella', 4.50, 'tama on erittain hyvaa')""",
        """INSERT INTO storage (amount, product_id) VALUES (60, 1)""",
        """INSERT INTO storage (amount, product_id) VALUES (30, 2)""",
        """INSERT INTO storage (amount, product_id) VALUES (10, 3)""",
    )

    try:
        con = psycopg2.connect(host=(ip), database = "piirakka", port=5432, user=(sqluser),password=(pw))

        cur = con.cursor()
        # create table one by one
        for command in sql:
            cur.execute(sql)
        # close communication with the PostgreSQL database server
        cur.close()
        # commit the changes
        con.commit()
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
            con.close()