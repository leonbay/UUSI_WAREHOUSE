from google.cloud import secretmanager
import psycopg2
import requests

def connect(self):

    client = secretmanager.SecretManagerServiceClient()
    ip2 = client.access_secret_version(request={"name": "projects/29618385328/secrets/sql-ipv42/versions/latest"})
    ip = ip2.payload.data.decode("UTF-8")

    pw2 = client.access_secret_version(request={"name": "projects/29618385328/secrets/sql-password2/versions/latest"})
    pw = pw2.payload.data.decode("UTF-8")

    sqluser2 = client.access_secret_version(request={"name": "projects/29618385328/secrets/sql-user2/versions/latest"})
    sqluser = sqluser2.payload.data.decode("UTF-8")
    

    con = psycopg2.connect(host=(ip), database = "piirakka", port=5432, user=(sqluser),password=(pw))

    try:
        con = psycopg2.connect(host=(ip), database="piirakka", port=5432, user=(sqluser), password=(pw))
        cursor = con.cursor()
        SQL = 'SELECT * FROM product;'
        cursor.execute(SQL)
        con.commit()
        product_information = cursor.fetchall()
        row = cursor.fetchone()
        while row is not None:
            print(f"{row[1]}, {row[2]}, {row[3]},{row[4]}")
            row = cursor.fetchone()
        cursor.close()
        con.close()
        return str(product_information)
    except:
        print("error")
