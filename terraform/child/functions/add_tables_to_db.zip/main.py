from google.cloud import secretmanager
import psycopg2
import requests

def add_tables(self):
    
    client = secretmanager.SecretManagerServiceClient()
    ip2 = client.access_secret_version(request={"name": "projects/29618385328/secrets/sql-ipv42/versions/latest"})
    ip = ip2.payload.data.decode("UTF-8")

    pw2 = client.access_secret_version(request={"name": "projects/29618385328/secrets/sql-password2/versions/latest"})
    pw = pw2.payload.data.decode("UTF-8")

    sqluser2 = client.access_secret_version(request={"name": "projects/29618385328/secrets/sql-user2/versions/latest"})
    sqluser = sqluser2.payload.data.decode("UTF-8")

    commands = (
        """CREATE TABLE IF NOT EXISTS customer (id serial PRIMARY KEY, username VARCHAR (255) UNIQUE NOT NULL, adress VARCHAR (255) NOT NULL, email VARCHAR (255)NOT NULL)""",

        """CREATE TABLE IF NOT EXISTS product (id serial PRIMARY KEY, pname VARCHAR (255) UNIQUE NOT NULL, category VARCHAR (255) NOT NULL, prize FLOAT NOT NULL, info VARCHAR(1000))""",

        """CREATE TABLE IF NOT EXISTS storage (id serial PRIMARY KEY, amount INT NOT NULL, product_id INT, CONSTRAINT fk_product FOREIGN KEY (product_id) REFERENCES product(id) ON DELETE SET NULL)""",

        """CREATE TABLE IF NOT EXISTS shoppingcart (
            id serial PRIMARY KEY,
            customer_id INT,
            product_id INT,
            amount INT NOT NULL,
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            CONSTRAINT fk_product FOREIGN KEY (product_id) REFERENCES product(id) ON DELETE SET NULL,
            CONSTRAINT fk_customer FOREIGN KEY (customer_id) REFERENCES customer(id) ON DELETE SET NULL)""",

        """CREATE TABLE IF NOT EXISTS order_info (id serial PRIMARY KEY,
            customer_id INT,
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            CONSTRAINT fk_customer_id FOREIGN KEY (customer_id) REFERENCES customer(id) ON DELETE SET NULL)""",

        """CREATE TABLE IF NOT EXISTS order_items (
            id serial PRIMARY KEY,
            order_info_id INT,
            product_id INT, 
            amount INT NOT NULL, 
            CONSTRAINT fk_order_info FOREIGN KEY (order_info_id) REFERENCES order_info(id) ON DELETE SET NULL,
            CONSTRAINT fk_product FOREIGN KEY (product_id) REFERENCES product(id) ON DELETE SET NULL)"""

    )

    try:
        con = psycopg2.connect(host=(ip), database = "piirakka", port=5432, user=(sqluser),password=(pw))

        cur = con.cursor()
        # create table one by one
        for command in commands:
            cur.execute(command)
        # close communication with the PostgreSQL database server
        cur.close()
        # commit the changes
        con.commit()
    except (Exception, psycopg2.DatabaseError) as error:
        print(error)
    finally:
            con.close()